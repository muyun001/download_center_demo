# -*- coding: utf8 -*-
import os
from buildin_sites.task.aizhan_task_excutor import AizhanTaskExcutor
from buildin_sites.spider.aizhan.extractor.az_base_extractor import AizhanBaseExtractor
from buildin_sites.spider.aizhan.extractor.az_keyword_extractor import AizhanKeywordExtractor
from buildin_sites.spider.aizhan.extractor.az_history_extractor import AizhanHisotryExtractor
from download_center.util.util_log import UtilLogger
import time
import sys
reload(sys)
sys.setdefaultencoding('utf8')


class AizhanSpider(AizhanTaskExcutor):
    def __init__(self):
        super(AizhanSpider, self).__init__()
        self.az_base_extractor = AizhanBaseExtractor()
        self.az_keyword_extractor = AizhanKeywordExtractor()
        self.az_history_extractor = AizhanHisotryExtractor()
        self.log = UtilLogger('AizhanSpider', os.path.join(os.path.dirname(os.path.abspath(__file__)),
                                                           'log/log_aizhan_spider'))

    def get_user_password(self):
        return 'system', 'system'

    def send_wait(self):
        """
        发送等待, 控制发往下载中心的速率
        """
        if self.sended_queue.qsize() > 4000:
            time.sleep(60)
        elif self.sending_queue.qsize() < 10000:
            time.sleep(0.1)

    def start_requests(self):
        self.log.info('内置爱站抓取程序开始启动...')
        while True:
            try:
                self.obtain_task(self.site, self.input_table)
            except Exception, e:
                self.log.error('获取初始请求出错:%s' % str(e))
            time.sleep(30)

    def deal_request_results(self, request, results):
        if results == 0:
            self.log.error('请求发送失败')
        elif results == -2:
            self.log.error('没有相应地域')
        else:
            self.log.info('请求发送成功')
            self.sended_queue.put(request)

    def get_stores(self):
        stores = list()
        return stores

    def deal_response_results(self, request, results, stores):
        if results == 0:
            self.log.error('获取结果失败')
        else:
            urls = list()
            for u in request.urls:
                unique_key = u['unique_md5']
                if unique_key in results:
                    result = results[unique_key]
                    if str(result['status']) == '2':
                        self.log.info('抓取成功:%s' % u['url'])
                        domain = u['domain']
                        input_id = u['input_id']
                        model = u['model']
                        task_id = u['task_id']
                        if model == 1:
                            r = self.az_base_extractor.extractor(result['result'])
                            r['domain'] = domain
                            r['input_id'] = input_id
                            key = str(task_id) + '#1'
                            self.add_to_store_queue({key: r}, task_id)
                        elif model == 2:
                            r = self.az_keyword_extractor.extractor(result['result'])
                            from_side = 1
                            if '/mobile/' in u['url']:
                                from_side = 0
                            for item in r:
                                item['domain'] = domain
                                item['input_id'] = input_id
                                item['from_side'] = from_side
                                key = str(task_id) + '#2'
                                self.add_to_store_queue({key: item}, task_id)
                        elif model == 3:
                            r = self.az_history_extractor.extractor(result['result'])
                            for item in r:
                                item['domain'] = domain
                                item['input_id'] = input_id
                                key = str(task_id) + '#3'
                                self.add_to_store_queue({key: item}, task_id)

                    elif str(result['status']) == '3':
                        self.log.info('抓取失败:%s' % u['url'])
                    else:
                        urls.append(u)
            if len(urls) > 0:
                request.urls = urls
                self.sended_queue.put(request)


def main():
    spider = AizhanSpider()
    spider.run(send_num=10, get_num=10, deal_num=10, store_num=10,
               send_idle_time=-1, get_idle_time=-1, deal_idle_time=-1, store_idle_time=-1)

if __name__ == '__main__':
    main()
