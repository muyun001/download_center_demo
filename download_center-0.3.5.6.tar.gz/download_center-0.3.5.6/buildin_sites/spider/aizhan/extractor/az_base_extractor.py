# -*- coding: utf-8 -*-
"""
 @Time: 2017/8/30 15:37
 @Author: sunxiang
"""
from download_center.new_spider.spider.spider import SpiderExtractor
import traceback
from lxml.html import fromstring
from lxml import etree
import sys
import re
from extractor_decorator import extractor_check

reload(sys)
sys.setdefaultencoding('utf8')


class AizhanBaseExtractor(SpiderExtractor):

    @extractor_check
    def extractor(self, text):
        """
        爱站基本信息
        -1 解析异常
        -2  页面异常
        """
        ext_result = dict()
        try:
            tree = fromstring(text.decode("utf-8", "ignore"))  # 这种方式 可使用cssselect  不然linux 不能使用
            content = tree.xpath('//div[@class="cha-infos"]/div[@class="content"]')
            if content:
                li_list = content[0].xpath('descendant::li')
                if li_list:
                    for li_one in li_list:
                        c_name = li_one.text
                        span = li_one.xpath('descendant::span')
                        if len(span) == 0:
                            span = li_one.xpath('descendant::a')
                        if span:
                            if c_name.find("百度来路") > -1:
                                ext_result["baidu_income"] = etree.tostring(span[0], encoding="utf-8", method="text").strip()
                            elif c_name.find("移动来路") > -1:
                                ext_result["mobile_income"] = etree.tostring(span[0], encoding="utf-8", method="text").strip()
                            elif c_name.find("出站链接") > -1:
                                ext_result["outbound_cnt"] = etree.tostring(span[0], encoding="utf-8", method="text").strip()
                            elif c_name.find("首页内链") > -1:
                                ext_result["index_inlink_cnt"] = etree.tostring(span[0], encoding="utf-8", method="text").strip()
                            elif c_name.find("百度权重") > -1:
                                r_content = etree.tostring(span[0], method="html", encoding="utf-8")
                                try:
                                    ext_result["baidu_rank"] = re.findall(r'r/(.*?).png', r_content)[0]
                                except:
                                    pass
                            elif c_name.find("移动权重") > -1:
                                r_content = etree.tostring(span[0], method="html", encoding="utf-8")
                                try:
                                    ext_result["mb_rank"] = re.findall(r'r/(.*?).png', r_content)[0]
                                except:
                                    pass
                            elif c_name.find("谷歌PR") > -1:
                                r_content = etree.tostring(span[0], method="html", encoding="utf-8")
                                try:
                                    ext_result["google_pr"] = re.findall(r'r/(.*?).png', r_content)[0]
                                except:
                                    pass
                            elif c_name.find("搜狗PR") > -1:
                                r_content = etree.tostring(span[0], method="html", encoding="utf-8")
                                try:
                                    ext_result["sogou_pr"] = re.findall(r'r/(.*?).png', r_content)[0]
                                except:
                                    pass

                            elif c_name.find("反链") > -1:
                                ext_result["backlink_cnt"] = etree.tostring(span[0], encoding="utf-8", method="text").strip()
                            elif c_name.find("世界排名") > -1:
                                ext_result["world_rank"] = etree.tostring(span[0], encoding="utf-8", method="text").strip()
                            elif c_name.find("预估日均IP") > -1:
                                ext_result["predict_daily_ip"] = etree.tostring(span[0], encoding="utf-8", method="text").strip()
                            elif c_name.find("预估日均PV") > -1:
                                ext_result["predict_daily_pv"] = etree.tostring(span[0], encoding="utf-8", method="text").strip()
                            elif c_name.find("备案号") > -1:
                                ext_result["icp_code"] = etree.tostring(span[0], encoding="utf-8", method="text").strip()
                            elif c_name.find("性质") > -1:
                                ext_result["icp_type"] = etree.tostring(span[0], encoding="utf-8", method="text").strip()
                            elif c_name.find("名称") > -1:
                                ext_result["icp_company"] = etree.tostring(span[0], encoding="utf-8", method="text").strip()
                            elif c_name.find("审核时间") > -1:
                                ext_result["icp_passtime"] = etree.tostring(span[0], encoding="utf-8", method="text").strip()
                            elif c_name.find("注册人/机构") > -1:
                                ext_result["whois_registrant"] = etree.tostring(span[0], encoding="utf-8", method="text").strip()
                            elif c_name.find("注册邮箱") > -1:
                                ext_result["whois_email"] = etree.tostring(span[0], encoding="utf-8", method="text").strip()
                            elif c_name.find("年龄") > -1:
                                ext_result["whois_create_time"] = etree.tostring(span[0], encoding="utf-8", method="text").strip()

                speed = tree.xpath('//ul[@id="speed"]/li[1]')
                if speed:
                    ext_result["ping_speed"] = etree.tostring(speed[0], encoding="utf-8", method="text").strip().strip()
            else:
                return -2

            cc1 = tree.xpath('//a[@id="cc1"]')
            if cc1:
                ext_result["pc_words"] = etree.tostring(cc1[0], encoding="utf-8", method="text").strip()

            cc2 = tree.xpath('//a[@id="cc2"]')
            if cc2:
                ext_result["mobile_words"] = etree.tostring(cc2[0], encoding="utf-8", method="text").strip()

            shoulu1 = tree.xpath('//a[@id="shoulu1_baiduposition"]')
            if shoulu1:
                ext_result["index_position"] = etree.tostring(shoulu1[0], encoding="utf-8", method="text").strip()

            indexes = tree.xpath('//a[@id="baiduindex"]')
            if indexes:
                ext_result["indexes"] = etree.tostring(indexes[0], encoding="utf-8", method="text").strip()

            shoulu3_1days = tree.xpath('//a[@id="shoulu3_1days"]')
            if shoulu3_1days:
                ext_result["include_daily"] = etree.tostring(shoulu3_1days[0], encoding="utf-8", method="text").strip()

            shoulu3_7days = tree.xpath('//a[@id="shoulu3_7days"]')
            if shoulu3_7days:
                ext_result["include_weekly"] = etree.tostring(shoulu3_7days[0], encoding="utf-8", method="text").strip()

            shoulu3_30days = tree.xpath('//a[@id="shoulu3_30days"]')
            if shoulu3_30days:
                ext_result["include_monthly"] = etree.tostring(shoulu3_30days[0], encoding="utf-8", method="text").strip()

            shoulu1_baidu = tree.xpath('//td[@id="shoulu1_baidu"]')
            if shoulu1_baidu:
                ext_result["baidu_include"] = etree.tostring(shoulu1_baidu[0], encoding="utf-8", method="text").strip()

            shoulu1_google = tree.xpath('//td[@id="shoulu1_google"]')
            if shoulu1_google:
                ext_result["google_include"] = etree.tostring(shoulu1_google[0], encoding="utf-8", method="text").strip()

            shoulu1_360 = tree.xpath('//td[@id="shoulu1_360"]')
            if shoulu1_360:
                ext_result["360_include"] = etree.tostring(shoulu1_360[0], encoding="utf-8", method="text").strip()

            shoulu1_sogou = tree.xpath('//td[@id="shoulu1_sogou"]')
            if shoulu1_sogou:
                ext_result["sugou_include"] = etree.tostring(shoulu1_sogou[0], encoding="utf-8", method="text").strip()

            shoulu2_baidu = tree.xpath('//td[@id="shoulu2_baidu"]')
            if shoulu2_baidu:
                ext_result["baidu_backlink"] = etree.tostring(shoulu2_baidu[0], encoding="utf-8", method="text").strip()

            shoulu2_google = tree.xpath('//td[@id="shoulu2_google"]')
            if shoulu2_google:
                ext_result["google_backlink"] = etree.tostring(shoulu2_google[0], encoding="utf-8", method="text").strip()

            shoulu2_360 = tree.xpath('//td[@id="shoulu2_360"]')
            if shoulu2_360:
                ext_result["360_backlink"] = etree.tostring(shoulu2_360[0], encoding="utf-8", method="text").strip()

            shoulu2_sogou = tree.xpath('//td[@id="shoulu2_sogou"]')
            if shoulu2_sogou:
                ext_result["sugou_ibacklink"] = etree.tostring(shoulu2_sogou[0], encoding="utf-8", method="text").strip()

            return ext_result
        except:
            print(traceback.format_exc())
            return -1

    def get_text(self, elem):
        rc = []
        for node in elem.itertext():
            rc.append(node.strip())
        return ''.join(rc)


if __name__ == '__main__':
    extractor = AizhanBaseExtractor()
    with open("html/az_base.txt", "rb") as f:
        #
        returntext = extractor.extractor(f.read())
        print returntext
        print len(returntext)
        for re in returntext:
            print re, returntext[re]
