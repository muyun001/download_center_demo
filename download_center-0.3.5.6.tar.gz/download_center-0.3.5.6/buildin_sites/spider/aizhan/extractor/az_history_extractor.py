# -*- coding: utf-8 -*-
"""
 @Time: 2017/8/30 17:41
 @Author: sunxiang
"""
from download_center.new_spider.spider.spider import SpiderExtractor
import traceback
from lxml.html import fromstring
from lxml import etree
import sys
from extractor_decorator import extractor_check

reload(sys)
sys.setdefaultencoding('utf8')


class AizhanHisotryExtractor(SpiderExtractor):

    @extractor_check
    def extractor(self, text):
        """
        爱站历史数据解析器
        示例：http://lishi.aizhan.com/51job.com/randabr/2017-07-01/2017-08-31/
        -1 解析异常
        -2 页面异常
        """
        ext_result = list()
        try:
            tree = fromstring(text.decode("utf-8", "ignore"))  # 这种方式 可使用cssselect  不然linux 不能使用
            lishi_content = tree.xpath('//div[@class="lishi-content"]/table/tbody/tr')
            if lishi_content:
                for i, v in enumerate(lishi_content):
                    ext_one = dict()
                    tds = v.xpath('descendant::td')
                    if tds:
                        for i2, v2 in enumerate(tds):
                            if i2 == 0:
                                ext_one["date"] = etree.tostring(v2, encoding="utf-8", method="text").strip()
                            elif i2 == 1:
                                ext_one["hs_pc_rank"] = etree.tostring(v2, encoding="utf-8", method="text").strip()
                            elif i2 == 2:
                                ext_one["hs_mb_rank"] = etree.tostring(v2, encoding="utf-8", method="text").strip()
                            elif i2 == 3:
                                ext_one["hs_pc_words"] = etree.tostring(v2, encoding="utf-8", method="text").strip()
                            elif i2 == 4:
                                ext_one["hs_mb_words"] = etree.tostring(v2, encoding="utf-8", method="text").strip()
                            elif i2 == 5:
                                ext_one["hs_baidu_pc_income"] = etree.tostring(v2, encoding="utf-8", method="text").strip()
                            elif i2 == 6:
                                ext_one["hs_baidu_mb_income"] = etree.tostring(v2, encoding="utf-8", method="text").strip()
                            elif i2 == 7:
                                ext_one["hs_total_income"] = etree.tostring(v2, encoding="utf-8", method="text").strip()
                        ext_result.append(ext_one)
            else:
                return -2
            return ext_result
        except:
            print(traceback.format_exc())
            return -1

    def get_text(self, elem):
        rc = []
        for node in elem.itertext():
            rc.append(node.strip())
        return ''.join(rc)


if __name__ == '__main__':
    extractor = AizhanHisotryExtractor()
    with open("html/az_history.txt", "rb") as f:
        returntext = extractor.extractor(f.read())
        import json
        for keyword in returntext:
            print json.dumps(keyword)
