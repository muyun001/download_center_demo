# -*- coding: utf-8 -*-
"""
 @Time: 2017/8/30 17:13
 @Author: sunxiang
"""
from download_center.new_spider.spider.spider import SpiderExtractor
import traceback
from lxml.html import fromstring
from lxml import etree
import sys
from extractor_decorator import extractor_check

reload(sys)
sys.setdefaultencoding('utf8')


class AizhanKeywordExtractor(SpiderExtractor):

    @extractor_check
    def extractor(self, text):
        """
        爱站关键词信息解析器
        示例：http://baidurank.aizhan.com/baidu/51job.com/
        -1 解析异常
        -2 页面异常
        """
        ext_result = list()
        try:
            tree = fromstring(text.decode("utf-8", "ignore"))  # 这种方式 可使用cssselect  不然linux 不能使用
            # tr_list = tree.xpath('//div[@class="baidurank-list"]//table[@class="table-s1"]')

            count_list = tree.xpath('//div[@class="baidurank-list"]/table/thead/tr/td')
            if count_list:
                count = len(count_list)
                # 5 mobile 6 pc

            tr_list = tree.xpath('//div[@class="baidurank-list"]/table/tbody/tr')
            if tr_list:
                for index, tr_one in enumerate(tr_list):
                    ext_one = dict()
                    tds = tr_one.xpath('descendant::td')
                    if tds:
                        for i, v in enumerate(tds):
                            if index == 0:
                                if i == 0:
                                    continue
                                elif i == 1:
                                    # print etree.tostring(v, encoding="utf-8", method="text").replace(" ", "").strip()
                                    ext_one["keyword"] = etree.tostring(v, encoding="utf-8", method="text").strip()
                                elif i == 2:
                                    ext_one["rank"] = etree.tostring(v, encoding="utf-8", method="text").replace("\n", "").replace("\t", "").strip()
                                elif i == 3:
                                    ext_one["search_cnt"] = etree.tostring(v, encoding="utf-8", method="text").strip()
                                elif count == 6:
                                    if i == 4:
                                        ext_one["include_cnt"] = etree.tostring(v, encoding="utf-8",
                                                                                method="text").strip()
                                    elif i == 5:
                                        ext_one["title"] = etree.tostring(v, encoding="utf-8", method="text").strip()
                                elif count == 5:
                                    if i == 4:
                                        ext_one["title"] = etree.tostring(v, encoding="utf-8", method="text").strip()

                            else:
                                if i == 0:
                                    # print etree.tostring(v, encoding="utf-8", method="text").replace(" ", "").strip()
                                    ext_one["keyword"] = etree.tostring(v, encoding="utf-8", method="text").strip()
                                elif i == 1:
                                    ext_one["rank"] = etree.tostring(v, encoding="utf-8", method="text").replace("\n", "").replace("\t", "").strip()
                                elif i == 2:
                                    ext_one["search_cnt"] = etree.tostring(v, encoding="utf-8", method="text").strip()
                                elif count == 6:
                                    if i == 3:
                                        ext_one["include_cnt"] = etree.tostring(v, encoding="utf-8",
                                                                                method="text").strip()
                                    elif i == 4:
                                        ext_one["title"] = etree.tostring(v, encoding="utf-8", method="text").strip()
                                elif count == 5:
                                    if i == 3:
                                        ext_one["title"] = etree.tostring(v, encoding="utf-8", method="text").strip()

                        ext_result.append(ext_one)
            else:
                return -2
            return ext_result
        except:
            print(traceback.format_exc())
            return -1

    def get_text(self, elem):
        rc = []
        for node in elem.itertext():
            rc.append(node.strip())
        return ''.join(rc)


if __name__ == '__main__':
    extractor = AizhanKeywordExtractor()
    with open("html/az_rank.txt", "rb") as f:
        returntext = extractor.extractor(f.read())
        import json
        for keyword in returntext:
            print json.dumps(keyword)
