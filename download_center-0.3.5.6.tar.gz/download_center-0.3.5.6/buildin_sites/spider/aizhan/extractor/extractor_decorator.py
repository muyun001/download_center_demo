# -*- coding: utf-8 -*-
"""
 @Time: 2017/9/6 16:41
 @Author: sunxiang
"""


def extractor_check(func):
    """
    监测网站改版
    :param func:
    :return: -1 解析异常 -2 网站有改版可能 -3 参数页面为空
    """
    def wrapper(*args):
        for arg in args:
            if arg:
                pass
            else:
                print("参数页面为空")
                return -3
        ret = func(*args)
        if ret == -1:
            print("解析异常")
        elif ret == -2:
            print("网站有改版可能")
        return ret
    return wrapper