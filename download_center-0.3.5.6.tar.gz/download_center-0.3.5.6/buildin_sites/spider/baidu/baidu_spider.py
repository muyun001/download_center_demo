# -*- coding: utf8 -*-
import os
from buildin_sites.task.baidu_task_excutor import BaiduTaskExcutor
from download_center.util.util_log import UtilLogger
from buildin_sites.spider.baidu.extractor.baidu_extractor import BaiduExtractor
from buildin_sites.spider.baidu.extractor.baidu_mobile_extractor import BaiduMobileExtractor
from buildin_sites.spider.baidu.extractor.snapshoot_extractor import SnapshootExtractor
from download_center.new_spider.downloader.downloader import SpiderRequest
import random
import time
import sys
reload(sys)
sys.setdefaultencoding('utf8')


class BaiduSpider(BaiduTaskExcutor):

    def __init__(self):
        super(BaiduSpider, self).__init__()
        self.baidu_extractor = BaiduExtractor()
        self.baidu_mobile_extractor = BaiduMobileExtractor()
        self.snapshoot_extractor = SnapshootExtractor()
        self.log = UtilLogger('BaiduSpider', os.path.join(os.path.dirname(os.path.abspath(__file__)),
                                                          'log/log_baidu_spider'))

    def get_user_password(self):
        return 'system', 'system'

    def send_wait(self):
        """
        发送等待, 控制发往下载中心的速率
        """
        if self.sended_queue.qsize() > 4000:
            time.sleep(60)
        elif self.sending_queue.qsize() < 10000:
            time.sleep(0.1)

    def start_requests(self):
        self.log.info('内置百度抓取程序开始启动...')
        while True:
            try:
                self.obtain_task(self.site, self.input_table)
            except Exception, e:
                self.log.error('获取初始请求出错:%s' % str(e))
            time.sleep(30)

    def deal_request_results(self, request, results):
        if results == 0:
            self.log.error('请求发送失败')
        elif results == -2:
            self.log.error('没有相应地域')
        else:
            self.log.info('Queue: %d' % self.sending_queue.qsize())
            self.log.info('请求发送成功')
            self.sended_queue.put(request)

    def get_stores(self):
        stores = list()
        return stores

    def deal_response_results(self, request, results, stores):
        if results == 0:
            self.log.error('获取结果失败')
        else:
            urls = list()
            for u in request.urls:
                unique_key = u['unique_md5']
                if unique_key in results:
                    result = results[unique_key]
                    if str(result['status']) == '2':
                        self.log.info('抓取成功:%s' % u['url'])
                        model = u['model']
                        task_id = u['task_id']
                        # 搜索结果页
                        if model == 1:
                            side = u['side']
                            input_id = u['input_id']

                            if side:
                                r = self.baidu_extractor.extractor(result['result'])
                                for item in r['data']:
                                    if not self.if_match(input_id, item):
                                        continue
                                    item['input_id'] = input_id
                                    item['keyword'] = u['keyword']
                                    item['page'] = u['page']
                                    key = str(task_id) + '#0'
                                    self.add_to_store_queue({key: item}, task_id)

                                    # 是否获取快照页信息
                                    if self.if_necessary(task_id, '3') and item.get('snapshoot_url'):
                                        req_urls = list()
                                        config = {'redirect': 1}
                                        req_urls.append(
                                            {'url': item['snapshoot_url'], 'type': 1, 'input_id': u['input_id'], 'page': u['page'],
                                             'keyword': u['keyword'], 'model': 2, 'task_id': u['task_id'],
                                             'unique_key': self.get_unique_key()})
                                        header = {'User-Agent': random.choice(self.pc_user_agents)}
                                        request = SpiderRequest(headers=header, config=config, urls=req_urls)
                                        self.add_spider_request(request)
                                # 是否存储统计信息
                                if self.if_necessary(task_id, '1'):
                                    r.pop('data')
                                    r['keyword'] = u['keyword']
                                    r['input_id'] = u['input_id']
                                    r['page'] = u['page']
                                    key = str(task_id) + '#1'
                                    self.add_to_store_queue({key: r}, task_id)
                            else:
                                r = self.baidu_mobile_extractor.extractor(result['result'])
                                for item in r:
                                    if not self.if_match(input_id, item):
                                        continue
                                    item['input_id'] = input_id
                                    item['keyword'] = u['keyword']
                                    item['page'] = u['page']
                                    # 百度搜索移动端首页有11条记录
                                    if int(item['page']) > 1:
                                        item['rank'] = (int(item['page'])-2)*10 + int(item['rank']) + 11
                                    key = str(task_id) + '#0'
                                    self.add_to_store_queue({key: item}, task_id)
                        # 快照页
                        elif model == 2:
                            r = self.snapshoot_extractor.extractor(result['result'])

                            r['keyword'] = u['keyword']
                            r['input_id'] = u['input_id']
                            r['page'] = u['page']
                            r['snapshoot_url'] = u['url']
                            key = str(task_id) + '#2'
                            self.add_to_store_queue({key: r}, task_id)
                        # 详情页
                        # elif model == 3:
                        #     real_url = result['redirect_url']
                        #     parent_id = u['parent_id']
                        #     r = {
                        #         'real_url': real_url,
                        #         'id': parent_id
                        #     }
                        #     self.store_queue.put({3: r})
                    elif str(result['status']) == '3':
                        self.log.info('抓取失败:%s' % u['url'])
                    else:
                        urls.append(u)
            if len(urls) > 0:
                request.urls = urls
                self.sended_queue.put(request)

    def if_match(self, input_id, data):
        """
        判断结果是否符合筛选条件
        :return:
        """
        if self.match_conditions.get(input_id):
            for field, condition in self.match_conditions[input_id].items():
                if data.get(field):
                    if condition not in data[field]:
                        return False
                else:
                    return False
        return True

    def if_necessary(self, task_id, field):
        """
        是否需要指定的信息
        :param task_id:
        :return:
        """
        task = self.task_mapping.get(task_id)
        if task:
            if field in task.fields.split(';'):
                return True
        return False


def main():
    spider = BaiduSpider()
    spider.run(send_num=10, get_num=10, deal_num=10, store_num=10,
               send_idle_time=-1, get_idle_time=-1, deal_idle_time=-1, store_idle_time=-1)

if __name__ == '__main__':
    main()
