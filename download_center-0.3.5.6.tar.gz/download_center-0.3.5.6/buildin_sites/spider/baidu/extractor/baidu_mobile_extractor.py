# -*- coding: utf-8 -*-
"""
 @Time: 2017/10/17 17:37
 @Author: sunxiang
"""
from download_center.new_spider.spider.spider import SpiderExtractor
import traceback
from lxml.html import fromstring
from lxml import etree
from extractor_decorator import extractor_check
import sys
reload(sys)
sys.setdefaultencoding('utf8')


class BaiduMobileExtractor(SpiderExtractor):

    """
    百度移动端搜索页面解析器
    示例：
    """
    @extractor_check
    def extractor(self, text):
        """

        """
        results = list()
        if text.find(u'页面不存在_百度搜索') > -1 or text.find(u'id="results"') < 0:
            return results
        else:
            try:
                tree = fromstring(text.decode("utf-8", "ignore"))
                containers = tree.cssselect('div#results .result')
                if containers:
                    for result in containers:
                        item = dict()
                        if result.cssselect("div.c-gap-top-small"):
                            desc = self.get_text(result.cssselect("div.c-gap-top-small")[0])
                            item['show_desc'] = desc
                        if result.cssselect("div.c-line-clamp1"):
                            show_url = self.remove_special_characters(self.get_text(result.cssselect("div.c-line-clamp1")[0]))
                            item['show_url'] = show_url
                        if result.cssselect("div.c-container a"):
                            url = result.cssselect("div.c-container a")[0].get('href')
                            item['url'] = url

                        if result.cssselect("h3"):
                            title = self.get_text(result.cssselect("h3")[0])
                            item['show_title'] = title
                        elif result.cssselect("div.c-title"):
                            # ‘其他人还在搜’区域
                            title = self.get_text(result.cssselect("div.c-title")[0])
                            item['show_title'] = title
                            desc = self.get_text(result.cssselect("div.c-gap-bottom-small")[0])
                            item['show_desc'] = desc
                            item['show_url'] = ''

                        order = result.get('order')
                        results.append(item)
                        item['rank'] = int(order)
                return results
            except Exception:
                print traceback.format_exc()
                return results


    def get_text(self, elem):
        rc = []
        for node in elem.itertext():
            rc.append(node.strip())
        return ''.join(rc)

    def remove_characters(self, previou_url):
        if previou_url.startswith("https://"):
            previou_url = previou_url.replace("https://", "")
        if previou_url.startswith("http://"):
            previou_url = previou_url.replace("http://", "")
        if previou_url.endswith("/"):
            previou_url = previou_url[0:len(previou_url) - 1]
        return previou_url

    def remove_special_characters(self, domain):
        domain = domain.replace("<b>", "")
        domain = domain.replace("</b>", "")
        domain = domain.replace("&nbsp", "")
        domain = domain.replace("›", "/")
        domain = domain.replace("...", "")
        domain = domain.replace(" ", "")
        return domain


if __name__ == '__main__':
    extractor = BaiduMobileExtractor()
    with open("html/baidu_mobile.txt", "rb") as f:
        returntext = extractor.extractor(f.read())
        import json
        print json.dumps(returntext)
