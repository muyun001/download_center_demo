# -*- coding: utf-8 -*-
"""
 @Time: 2017/8/30 15:16
 @Author: sunxiang
"""
from download_center.new_spider.spider.spider import SpiderExtractor
import traceback
import re
from lxml.html import fromstring
from lxml import etree
import sys
from extractor_decorator import extractor_check

reload(sys)
sys.setdefaultencoding('utf8')


class SnapshootExtractor(SpiderExtractor):

    @extractor_check
    def extractor(self, text):
        """
        百度快照页面解析器
        示例：
        """
        primary_title = ""
        snapshoot_update_time = ""
        real_url = ""
        try:
            text_empty = str(text).replace("\n", "").replace("\r", "")
            titles = re.findall(r'<title.*?>(.*?)</title>', text_empty)
            if titles:
                primary_title = titles[0]

            real_url_eles = re.findall(r'百度和网页.*?>(.*?)<', text_empty)
            if real_url_eles:
                real_url = real_url_eles[0]

            tree = fromstring(text.decode("utf-8", "ignore"))  # 这种方式 可使用cssselect  不然linux 不能使用
            ext_result = dict()

            bd_snap_txt = tree.cssselect('div#bd_snap_txt')
            if bd_snap_txt:
                content = etree.tostring(bd_snap_txt[0], encoding="utf-8", method="text")
                lis = re.findall(r'时间(.*?)的快照', content)
                if lis:
                    snapshoot_update_time = str(lis[0]).strip()
            else:
                return -2

            html = ""
            html_tree = tree.xpath('//body/div')
            if html_tree:
                index = len(html_tree) - 1
                html = etree.tostring(html_tree[index], encoding="utf-8", method="html")

            ext_result["real_url"] = real_url
            ext_result["primary_html"] = html
            ext_result["primary_title"] = primary_title
            ext_result["snapshoot_update_time"] = snapshoot_update_time
            return ext_result
        except:
            print(traceback.format_exc())
            return -1

    def get_text(self, elem):
        rc = []
        for node in elem.itertext():
            rc.append(node.strip())
        return ''.join(rc)


if __name__ == '__main__':
    extractor = SnapshootExtractor()
    with open("html/snapshoot.txt", "rb") as f:
        returntext = extractor.extractor(f.read())
        print(returntext["primary_title"])
        print(returntext["real_url"])
        import json
        print(json.dumps(returntext))
