# -*- coding: utf-8 -*-
"""
Created on 2017/10/18 21:40

@author: zhangle
"""
import buildin_sites.task.configs as cfs
from buildin_sites.task.task import Task
from download_center.new_spider.downloader import configs
from download_center.store.store_mysql import StoreMysql
import redis
import time
import json
import sys
reload(sys)
sys.setdefaultencoding('utf8')

user_db = {
        "host": "123.206.214.163", "password": "ZhangLe@0910", "db": "data_collect", "user": "zhangle", "port": 3306
}
redisPool = redis.ConnectionPool(**cfs.TASK_CENTER_REDIS[configs.ENVIR])
rds = redis.StrictRedis(connection_pool=redisPool)
db = StoreMysql(**user_db)

# all_input_ids = rds.scan()
# for input_id in all_input_ids[1]:
#     if '#' in input_id and 'baidu_input' in input_id:
while True:
    for i in range(170000, 190000):
            input_id = '10.154.49.122#baidu_input#'+str(i)
            size = rds.hlen(input_id)
            host, table, id = input_id.split('#')[0], input_id.split('#')[1], input_id.split('#')[2]
            if size == 1:
                task_id = rds.hget(input_id, 'first')
                db.update(table, {'id': int(id), 'status': 3}, 'id')
                rds.hdel(input_id, 'first')
                print input_id
                rds.hdel(cfs.TASK_SENDED_REQUEST % str(task_id), input_id)

                # if rds.hlen(cfs.TASK_SENDED_REQUEST % str(task_id)) == 0:
                #     # while store_queue.qsize() > 0:
                #     #     pass
                #     # mapping.pop(int(task_id))
                #     user_db.close_all()
            elif size > 1:
                pass
    print 'end'
