# -*- coding: utf8 -*-
from buildin_sites.task.task import TaskProcessor
from buildin_sites.task.task import Task
import sys
reload(sys)
sys.setdefaultencoding('utf8')


class AddTask(TaskProcessor):

    def get_user_password(self):
        """
        系统分配的user，password
        :return:
        """
        return 'username', 'password'

    def add_task(self):
        """
        添加任务
        """
        task = Task(host='test.com', user='test', password='passwprd', site=1, fields='1;2')
        self.task_queue.put(task)

    def deal_task_results(self, task, results):
        """
        添加任务结果处理
        :param task:
        :param results:
        :return:
        """
        if results == -1:
            self.log.error('任务添加失败')
        else:
            self.log.error('任务添加成功')
