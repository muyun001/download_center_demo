# -*- coding: utf8 -*-
from download_center.new_spider.downloader.downloader import SpiderRequest
from download_center.new_spider.spider.basespider import BaseSpider
from download_center.new_spider.util.util_md5 import UtilMD5
from buildin_sites.task import configs as cfs
from buildin_sites.task.task_excutor import TaskExcutor
import json
import random
import time
import datetime
import MySQLdb

import sys
reload(sys)
sys.setdefaultencoding('utf8')


class AizhanTaskExcutor(BaseSpider, TaskExcutor):

    """
    爱站抓取程序的基础类
    """
    def __init__(self):
        # super(AizhanTaskExcutor, self).__init__()
        BaseSpider.__init__(self)
        TaskExcutor.__init__(self)
        self.site = 2
        self.input_table = 'aizhan_input'

        self.base_seed = 'http://www.aizhan.com/cha/%s/'
        self.bdrank_seed = 'http://baidurank.aizhan.com/%s/%s/-1/0/%d/position/1/'
        self.history_seed = 'http://lishi.aizhan.com/%s/'

    def obtain_spider_request(self):
        while True:
            for task_id, task_detail in self.task_mapping.items():
                if task_detail.input_cnt <= 0:
                    continue
                user_db = self.task_db_mapping.get(task_id)
                while True:
                    if self.sending_queue.qsize() > 2000:
                        time.sleep(5)
                        continue
                    rows = user_db.query('select id, domain, params from %s where status = 1 limit 500' % self.input_table)
                    for row in rows:
                        if not self.validate_input(row):
                            continue
                        config = {'redirect': 1}
                        # 根据需要的字段判断发送何种请求
                        params = json.loads(row[2]) if row[2] else None
                        for table_id in task_detail.fields.split(';'):
                            tasks = dict()
                            table = cfs.TABLES[cfs.BUILDIN_SITES[self.site]][int(table_id)]
                            if 'aizhan_output_base' == table:
                                url = self.base_seed % row[1]
                                model = 1
                                tasks[url] = model
                            elif 'aizhan_output_keywords' == table:
                                # 判断获取移动端还是PC端数据
                                mode = 'baidu'
                                if params:
                                    if 'keyword_side' in params.keys():
                                        if int(params['keyword_side']) == 0:
                                            mode = 'mobile'
                                page = 1
                                if params:
                                    if 'keyword_page' in params.keys():
                                        page = int(params['keyword_page'])
                                for i in range(1, page+1):
                                    url = self.bdrank_seed % (mode, row[1], i)
                                    model = 2
                                    tasks[url] = model
                            elif 'aizhan_output_history' == table:
                                url = self.history_seed % row[1]
                                model = 3
                                # 查询时间区间
                                if params:
                                    if 'range' in params.keys():
                                        url = url + 'randabr/' + params['range'] + '/'
                                tasks[url] = model
                            for url, model in tasks.items():
                                urls = list()
                                urls.append({'url': url, 'type': 1, 'input_id': row[0], 'task_id': task_id,
                                             'domain': row[1], 'model': model,
                                             'unique_key': str(self.get_unique_key())})

                                header = {'User-Agent': random.choice(self.pc_user_agents)}
                                request = SpiderRequest(headers=header, config=config, urls=urls)
                                self.add_spider_request(request)

                        result = {
                            'id': row[0],
                            'status': 2,
                            'updated_time': datetime.datetime.now()
                        }
                        user_db.update(self.input_table, result, 'id')
                    task_detail.input_cnt -= 500
                    break

    def post_spider_result(self, results):
        for key, result in results.items():
            task_id, type = int(key.split('#')[0]), int(key.split('#')[1])
            task = self.task_mapping.get(task_id)

            for field in result.keys():
                result[field] = MySQLdb.escape_string(str(result[field]))
            if type == 1:
                domain = result.pop('domain')
                input_id = result.pop('input_id')
                r = {
                    'domain': domain,
                    'input_id': input_id,
                    'data': json.dumps(result, ensure_ascii=False),
                    'created_time': datetime.datetime.now(),
                    'updated_time': datetime.datetime.now()
                }
                self.task_db_mapping[task.identity].save('aizhan_output_base', r)
            elif type == 2:
                result['created_time'] = datetime.datetime.now()
                result['updated_time'] = datetime.datetime.now()
                self.task_db_mapping[task.identity].save('aizhan_output_keywords', result)
            elif type == 3:
                result['created_time'] = datetime.datetime.now()
                result['updated_time'] = datetime.datetime.now()
                self.task_db_mapping[task.identity].save('aizhan_output_history', result)

    def add_to_store_queue(self, results, task):
        """
        添加存储结果至存储队列及其他操作
        :param results:
        :param task:
        :return:
        """
        data = {
            'result': results,
            'task': task
        }
        self.store_queue.put(data)
        if self.task_store_mapping.get(task):
            self.task_store_mapping[task] += 1
        else:
            self.task_store_mapping[task] = 1

    def to_store_results(self, results, stores):
        # 存储具体操作
        self.post_spider_result(results.pop('result'))
        self.task_store_mapping[results.pop('task')] -= 1

    def add_spider_request(self, request):
        """
        添加SpiderRequest到sending_queue
        :param request:
        :return:
        """
        self.sending_queue.put(request)
        for u in request.urls:
            md5 = UtilMD5.md5(MySQLdb.escape_string(u['url']) + str(u['unique_key']))
            task_id = u['task_id']
            user_db = self.task_db_mapping[task_id]
            name = str(user_db.host) + "#" + self.input_table + '#' + str(u['input_id'])
            self.add_tasking_group_by_input_id(name, md5, task_id=task_id)

    def after_deal_response(self, request, results):
        """
        把执行完成的任务从redis中用于统计任务是否完成的队列中删除
        :param request:
        :param results:
        :return:
        """
        if results == 0:
            pass
        else:
            for u in request.urls:
                md5 = u['unique_md5']
                task_id = u['task_id']
                if md5 in results:
                    result = results[md5]
                    if str(result['status']) == '2' or str(result['status']) == '3':
                        user_db = self.task_db_mapping[task_id]
                        name = str(user_db.host) + "#" + self.input_table + '#' + str(u['input_id'])
                        self.remove_tasked_group_by_input_id(name, md5, task_id)

    def validate_input(self, row):
        """
        暂未实现
        """
        return True
