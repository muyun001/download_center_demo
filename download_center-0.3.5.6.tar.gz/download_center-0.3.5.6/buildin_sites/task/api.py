# -*- coding: utf8 -*-
from flask import Flask, jsonify, request
from buildin_sites.task.task import TaskProcessor, Task
import json
import sys
reload(sys)
sys.setdefaultencoding('utf8')

app = Flask(__name__)


@app.route('/addtask', methods=['POST'])
def add_task():
    processor = TaskProcessor()
    try:
        user = request.args.get('user')
        passwd = request.args.get('passwd')
        processor.validate_user(user, passwd)
    except:
        return jsonify({'message': '用户验证失败'})

    try:
        r = json.loads(request.data)
    except:
        return jsonify({'status': 0, 'message': '非法json格式'})

    invalid_fields = list()
    for key in r.keys():
        if key not in Task.obtain_all_fields():
            invalid_fields.append(key)
    if invalid_fields:
        return jsonify({'status': 0, 'message': '非法字段： %s' % ",".join(invalid_fields)})

    task = Task(**r)
    try:
        processor.before_insert(task)
    except Exception, e:
        msg = e.message
        return jsonify({'status': 0, 'message': msg})

    if not -1 == processor.insert(task):
        return jsonify({'status': 1, 'message': '添加任务成功'})
    else:
        return jsonify({'status': 0, 'message': '添加任务失败'})


@app.route('/sql/<filename>')
def sql(filename):
    return app.send_static_file('sql/'+filename)


@app.route('/doc/<filename>')
def doc(filename):
    return app.send_static_file('doc/'+filename)


@app.route('/image/<filename>')
def image(filename):
    return app.send_static_file('image/'+filename)


@app.route('/soft/<filename>')
def soft(filename):
    return app.send_static_file('soft/'+filename)

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=80)
