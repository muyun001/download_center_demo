# -*- coding: utf8 -*-

# 任务中心redis
TASK_CENTER_REDIS = {
    'outer': {
        'host': '123.206.214.163',
        'port': 6379,
        'db': 0,
        'password': '@redisForSpider$'
    },
    'inner': {
        'host': '10.154.49.122',
        'port': 6379,
        'db': 0,
        'password': '@redisForSpider$'
    }
}

TASK_SENDED_REQUEST = '%s:sended:request'

# 用户输入输出数据库及表默认名字、暂不支持自定义
DATABASE_DEFAULT = 'data_collect'

# 是否使用缓存
CACHE_DATA = {
    1: 'yes',
    0: 'no'
}

# 抓取中心内置的站点
BUILDIN_SITES = {
    1: 'baidu',
    2: 'aizhan'
}

# 支持的对用户输出表的操作
DATA_OPERATE_TYPE = {
    1: 'insert',
    2: 'update',
    3: 'cover'
}

# 每个站点包含的表名
TABLES = {
    'baidu': {
        1: 'baidu_output_statistics',
        2: 'baidu_output_results',
        3: 'baidu_output_snapshoot'
    },
    'aizhan': {
        1: 'aizhan_output_base',
        2: 'aizhan_output_keywords',
        3: 'aizhan_output_history'
    }
}

# 每张表存储的的需从网页上获取的字段
FIELDS = {
    'baidu_output_statistics': [
        'nature_cnt',
        'relate_cnt',
        'ad_cnt',
        'baidu_product_cnt',
        'aladdin_cnt',
    ],
    'baidu_output_results': [
        'show_url',
        'show_title',
        'show_desc',
        'show_date',
        'url',
        'snapshoot_url',
        'rank',
        'special_mark',
    ],
    'baidu_output_snapshoot': [
        'snapshoot_url',
        'primary_title',
        'primary_html',
        'snapshoot_update_time',
        'real_url'
    ],
    'aizhan_output_base': [
        'baidu_income',
        'mobile_income',
        'outbound_cnt',
        'index_inlink_cnt',
        'baidu_rank',
        'google_pr',
        'sogou_pr',
        'backlink_cnt',
        'world_rank',
        'predict_daily_ip',
        'predict_daily_pv',
        'icp_code',
        'icp_type',
        'icp_company',
        'icp_passtime',
        'whois_registrant',
        'whois_email',
        'whois_create_time',
        'ping_speed',
        'pc_words',
        'mb_words',
        'index_position',
        'indexes',
        'include_daily',
        'include_weekly',
        'include_monthly',
        'baidu_include',
        'baidu_backlink',
        'google_include',
        'google_backlink',
        'sogou_include',
        'sogou_backlink',
        '360_include',
        '360_backlink',
    ],
    'aizhan_output_keywords': [
        'from_side',
        'keyword',
        'rank',
        'title',
        'search_cnt',
        'include_cnt',
    ],
    'aizhan_output_history': [
        'date',
        'hs_pc_rank',
        'hs_mb_rank',
        'hs_pc_words',
        'hs_mb_words',
        'hs_baidu_pc_income',
        'hs_baidu_mb_income',
        'hs_total_income',
    ],
}

