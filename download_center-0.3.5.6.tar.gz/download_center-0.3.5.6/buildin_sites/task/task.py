# -*- coding: utf8 -*-
from download_center.store.store_mysql import StoreMysql
from download_center.new_spider.downloader import configs
from download_center.new_spider.util.util_md5 import UtilMD5
from Queue import LifoQueue
from Queue import Empty
from threading import Thread
import time
import traceback
import json
from buildin_sites.task import configs as cfs

import sys
reload(sys)
sys.setdefaultencoding('utf8')


class TaskProcessor(object):
    """
    发送抓取任务的基础类
    """
    def __init__(self):
        self.db = StoreMysql(**configs.DOWNLOADER_CENTER_DB[configs.ENVIR])
        self.task_queue = LifoQueue()
        self.user_id = 0

    def get_user_password(self):
        """
        设置用户名和密码，由子类实现。用于爬取前验证是否合法
        """
        raise NotImplementedError()

    def add_task(self):
        """
        添加任务，由子类实现。
        """
        raise NotImplementedError()

    def deal_task_results(self, task, results):
        """
        添加任务add_task后的处理逻辑，由子类实现
        Args:
            task:Task对象
            results:添加task后的返回对象
        """
        raise NotImplementedError()

    def validate_user(self, user, password):
        """
        验证用户
        """
        rows = self.db.query('select id from user where user = "%s" and password = "%s"' % (user, UtilMD5.md5(password)))
        if len(rows) == 1:
            self.user_id = rows[0][0]
        else:
            raise RuntimeError('用户验证失败')

    def deal_task(self, max_idle_time):
        """
        对队列中的任务进行处理
        """
        start_time = time.time()
        while True:
            try:
                task = self.task_queue.get_nowait()
                self.before_insert(task)
                self.deal_task_results(task, self.insert(task))
                start_time = time.time()
                self.get_wait()
            except Empty:
                if start_time + max_idle_time < time.time():
                    if self.is_finish():
                        break
                time.sleep(10)
            except Exception, e1:
                print(traceback.format_exc())

    def before_insert(self, task):
        """
        task参数验证
        :param task:
        :return:
        """
        if task.host is None:
            raise RuntimeError('数据库host为空')
        elif task.user is None:
            raise RuntimeError('数据库user为空')
        elif task.password is None:
            raise RuntimeError('password为空')
        elif task.db is None:
            raise RuntimeError('db名称为空')
        elif task.site is None:
            raise RuntimeError('site为空')
        elif task.cache is None:
            raise RuntimeError('cache为空')
        elif task.fields is None:
            raise RuntimeError('fields为空')
        args = dict(host=task.host, user=task.user, passwd=task.password, port=task.port, db=task.db,
                    use_unicode=True, charset="utf8", init_command='SET names utf8')
        if not StoreMysql.validate_connect(args):
            raise RuntimeError('数据库无法连接')
        if task.site not in cfs.BUILDIN_SITES.keys():
            raise RuntimeError('非法site值')
        if task.operate_type not in cfs.DATA_OPERATE_TYPE.keys():
            raise RuntimeError('非法operate_type值')
        if task.cache not in cfs.CACHE_DATA.keys():
            raise RuntimeError('非法cache值')
        status, message = self.validate_fields(task.site, str(task.fields))
        if not status:
            raise RuntimeError(message)
        if task.params and not isinstance(task.params, dict):
            raise RuntimeError('params格式应为json，如{"key1":"value1", "key2":"value2"}')

    def validate_fields(self, site, fields):
        groups = fields.split(';')
        if not groups:
            return False, 'fields格式错误'
        for group in groups:
            if not group:
                continue
            # 颗粒度为字段
            # if '=' not in group:
            #     return False, 'fields格式错误'
            # table, field = group.split('=')
            # if int(table) not in cfs.TABLES[cfs.BUILDIN_SITES[site]].keys():
            #     return False, 'fields字段存在错误的table_id: %s' % table
            # if not set(field.split(',')).issubset(set(self._obtain_available_fields(site, int(table)))):
            #     return False, 'fields字段中table_id %s 对应的字段错误' % table
            # 颗粒度为表
            if int(group) not in cfs.TABLES[cfs.BUILDIN_SITES[site]].keys():
                return False, 'fields中存在非法值: %s' % group
        return True, 'fields验证正确'

    @staticmethod
    def obtain_available_fields_dict(site, fields):
        r = dict()
        for group in str(fields).split(';'):
            if group:
                # 颗粒度为字段
                # table_id, field = group.split('=')
                # if table_id and field:
                #     table = cfs.TABLES[cfs.BUILDIN_SITES[int(site)]][int(table_id)]
                #     r[table] = field.split(',')
                # table = cfs.TABLES[cfs.BUILDIN_SITES[int(site)]][int(group)]
                # r[table] = field.split(',')

                # 颗粒度为表
                table = cfs.TABLES[cfs.BUILDIN_SITES[int(site)]][int(group)]
                r[table] = cfs.FIELDS[table]
        return r

    @staticmethod
    def separate_2_each_table(site_id, items):
        site = cfs.BUILDIN_SITES[site_id]
        results = dict()
        if isinstance(items, dict):
            for table in cfs.TABLES[site].values():
                results[table] = dict()
            for key, value in items.items():
                for table in cfs.TABLES[site].values():
                    if key in cfs.FIELDS[table]:
                        results[table][key] = value
        elif isinstance(items, list):
            for table in cfs.TABLES[site].values():
                results[table] = list()
            for field in items:
                for table in cfs.TABLES[site].values():
                    if field in cfs.FIELDS[table]:
                        results[table].append(field)
        return results

    @staticmethod
    def _obtain_available_fields(site, table_id):
        table = cfs.TABLES[cfs.BUILDIN_SITES[site]][table_id]
        return cfs.FIELDS[table]

    def insert(self, task):
        """
        保存任务
        :param task:
        :return:
        """
        db = {
                'host': task.host,
                'user': task.user,
                'password': task.password,
                'port': task.port,
                'db': task.db,
        }
        data = {
            'db': json.dumps(db),
            'site': task.site,
            'cache': task.cache,
            'operate_type': task.operate_type,
            'fields': task.fields,
            'created_by': self.user_id,
            'updated_by': self.user_id
        }
        if task.params:
            data['params'] = json.dumps(task.params)
        return self.db.save('task', data)

    def send_wait(self):
        """
        等待
        """
        time.sleep(1)

    def is_finish(self):
        """
        根据相关队列是否全都为空来判断任务处理结束
        """
        return self.task_queue.qsize() == 0

    def run(self, deal_idle_time=300):
        self.validate_user(self.get_user_password())
        t = Thread(target=self.deal_task, args=(deal_idle_time,))
        t.start()
        t = Thread(target=self.add_task)
        t.start()


class Task(object):

    def __init__(self, identity=None, host=None, user=None, password=None, site=None, fields=None, params=None,
                 operate_type=1, cache=1, port=3306, db='data_collect'):
        """

        :param identity:
        :param host: 数据库地址
        :param user: 数据库用户
        :param password: 数据库密码
        :param port: 数据库端口
        :param site: 任务类型，指定是哪个网站，具体值参考confis.py
        :param cache: 是否使用缓存数据
        :param operate_type: 数据操作类型，具体值参考confis.py
        :param fields: 需要获取的字段
        :param params: 其他参数
        :param db: 数据库名称
        """
        self.identity = identity
        self.host = host
        self.user = user
        self.password = password
        self.db = db
        self.port = port
        self.site = site
        self.cache = cache
        self.operate_type = operate_type
        self.fields = fields
        self.params = params
        self.input_cnt = 0

    @staticmethod
    def obtain_all_fields():
        f = [
            'host',
            'user',
            'db',
            'port',
            'password',
            'site',
            'cache',
            'operate_type',
            'fields',
            'params'
        ]
        return f


if __name__ == '__main__':
    l = ['kk']
    p = ['t', 's']
    print set(l).issubset(set(p))
