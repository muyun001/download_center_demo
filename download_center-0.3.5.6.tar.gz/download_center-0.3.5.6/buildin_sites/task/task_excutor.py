# -*- coding: utf8 -*-
from download_center.store.store_mysql_pool import StoreMysqlPool
import buildin_sites.task.configs as cfs
from buildin_sites.task.task import Task
from download_center.new_spider.downloader import configs
from download_center.store.store_mysql import StoreMysql
import redis
import json
import datetime
from threading import Thread
import time
import sys
reload(sys)
sys.setdefaultencoding('utf8')


class TaskExcutor(object):
    """
    任务执行基础类
    """
    def __init__(self):
        self.redisPool = redis.ConnectionPool(**cfs.TASK_CENTER_REDIS[configs.ENVIR])
        self.db = StoreMysql(**configs.DOWNLOADER_CENTER_DB[configs.ENVIR])
        # 任务ID与输出数据库的对应
        self.task_db_mapping = dict()
        # 任务ID与任务的对应
        self.task_mapping = dict()
        # 任务与最终存储结果的对应
        self.task_store_mapping = dict()

        # 轮询每个任务的输入表，保证每个任务可以并行
        task_loop_t = Thread(target=self.obtain_spider_request)
        task_loop_t.start()

        # 任务完成检查线程
        task_finish_check = Thread(target=self.check_if_finished,)
        task_finish_check.start()

    def obtain_task(self, site, input_table):
        tasks = self.db.query('select id, db, cache, operate_type, fields, params from task '
                              'where site = %d and status = 1 limit 1' % site)
        if not tasks:
            return
        task = self.encapsulate_2_obejct(site, tasks[0])

        self.db.update('task', {'id': task.identity, 'status': 0}, 'id')
        user_db = StoreMysqlPool(host=task.host, user=task.user, password=task.password, db=task.db)
        self.task_db_mapping[task.identity] = user_db

        count = user_db.query('select count(1) from %s where status = 1' % input_table)
        count = count[0][0]
        if count > 0:
            task.input_cnt = count
            self.task_mapping[task.identity] = task

    def obtain_spider_request(self):
        """
        从任务库获取任务数据，包装成SpiderRequest
        :return: 返回SpiderRequest列表
        """
        raise NotImplementedError()

    def post_spider_result(self, results):
        """
        处理抽取器处理后的结果，获取所需数据，存储到用户输出表
        :param results: 抽取器处理后的数据
        :return:
        """
        raise NotImplementedError()

    def validate_input(self, row):
        """
        验证用户输入信息，并反馈
        :param row: 用户数据库的一条输入记录
        :return:
        """
        raise NotImplementedError()

    def add_tasking_group_by_input_id(self, input_id, request_id, task_id):
        """
        以input_id为key，把正在执行的SpiderRequest请求添加到队列中
        目的：1.判断某条输入数据是否完成 2.判断task是否完成（一条task可能包含多条input数据）
        :param input_id:
        :param request_id:
        :param task_id:
        :return:
        """
        rds = redis.StrictRedis(connection_pool=self.redisPool)
        if rds.hlen(input_id) == 0:
            rds.hset(input_id, 'first', task_id)
        rds.hset(input_id, request_id, 1)
        rds.hset(cfs.TASK_SENDED_REQUEST % str(task_id), input_id, 1)

    def remove_tasked_group_by_input_id(self, input_id, request_id, task_id):
        """
        以input_id为key，把正在执行的SpiderRequest请求添加到队列中
        :param input_id:
        :param request_id:
        :param task_id:
        :return:
        """
        rds = redis.StrictRedis(connection_pool=self.redisPool)
        rds.hdel(input_id, request_id)
        # check
        size = rds.hlen(input_id)
        host, table, id = input_id.split('#')[0], input_id.split('#')[1], input_id.split('#')[2]
        if size == 1:
            # task_id = rds.hget(input_id, 'first')
            result = {
                'id': int(id),
                'status': 3,
                'updated_time': datetime.datetime.now()
            }
            user_db = self.task_db_mapping.get(int(task_id))
            user_db.update(table, result, 'id')
            rds.hdel(input_id, 'first')
            rds.hdel(cfs.TASK_SENDED_REQUEST % task_id, input_id)
        # elif size > 1:
        #     user_db.update(table, {'id': int(id), 'status': 2}, 'id')

    def check_if_finished(self):
        """
        通过检查redis中相应input_id的队列是否为空来判断任务是否完成
        完成后: 1.修改用户输入数据的状态 2.关闭和用户数据库的连接
        :return:
        """
        while True:
            rds = redis.StrictRedis(connection_pool=self.redisPool)
            for task_id, task in self.task_mapping.items():
                if (not self.task_store_mapping.get(int(task_id)) or self.task_store_mapping.get(int(task_id)) <= 0) and \
                                task.input_cnt <= 0 and rds.hlen(cfs.TASK_SENDED_REQUEST % task_id) == 0:
                    user_db = self.task_db_mapping[int(task_id)]
                    user_db.close_all()
                    self.task_mapping.pop(int(task_id))
                    self.task_db_mapping.pop(int(task_id))
            time.sleep(5)

    def encapsulate_2_obejct(self, site, row):
        """
        数据库记录封装成Task对象
        :param site:
        :param row:
        :return:
        """
        user_db_args = json.loads(row[1])
        fields = str(row[4])
        operate_type = int(row[3])
        if 'db' not in user_db_args.keys():
            user_db_args['db'] = cfs.DATABASE_DEFAULT
        task = Task(identity=row[0], site=site, fields=fields, operate_type=operate_type, **user_db_args)
        return task

