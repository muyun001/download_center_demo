# -*- coding: utf8 -*-
import sys
reload(sys)
sys.setdefaultencoding('utf8')


class DomainUtil(object):

    @staticmethod
    def format_validate(domain):
        pass