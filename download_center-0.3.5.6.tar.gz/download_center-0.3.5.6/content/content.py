# -*- coding: utf8 -*-

from download_center.store.store_es import StoreEs

import sys
reload(sys)
sys.setdefaultencoding('utf8')


class Content(object):
    """
    内容处理(暂不可用)
    用于临时存储、查询抓取的历史数据
    """
    def __init__(self):
        # self.es = StoreEs()
        pass

    def query(self):
        """
        查询满足条件的记录
        :return:
        """
        pass

    def save(self):
        pass

    def clear(self):
        """
        清除过期数据
        :return:
        """
        pass

