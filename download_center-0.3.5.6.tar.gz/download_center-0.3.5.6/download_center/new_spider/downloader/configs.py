# -*- coding: utf8 -*-
from download_center.new_spider.util.util_ping import Ping

# 下载中心地址
# DOWNLOADER_CENTER_URL = 'http://10.133.195.238/task.php'
DOWNLOADER_CENTER_URL = 'http://182.254.155.218/task.php'

# 发送任务方法
SEND_TASK_METHOD = 'sendTask'

# 发送任务超时时间
SEND_TASK_TIMEOUT = 300

# 查询任务方法
QUERY_TASK_METHOD = 'getResult'

# 查询任务超时时间
QUERY_TASK_TIMEOUT = 100

# 下载中心数据库
DOWNLOADER_CENTER_DB = {
    'outer': {
        'host': '182.254.155.218',
        'user': 'spider_center',
        'password': 'spiderdb@wd',
        'db': 'spider'
    },
    'inner': {
        'host': '10.105.72.2',
        'user': 'spider_center',
        'password': 'spiderdb@wd',
        'db': 'spider'
    }

}

# 下载中心redis
DOWNLOADER_CENTER_REDIS = {
    'outer': {
        'host': '182.254.155.218',
        'port': 6379,
        'db': 0,
        'password': '@redisForSpider$'
    },
    'inner': {
        'host': '10.105.72.2',
        'port': 6379,
        'db': 0,
        'password': '@redisForSpider$'
    }
}

# 数据库里面url type与抓取类型对应关系
FETCH_TYPES = {
    '1': 'html',
    '2': 'html',
    '3': 'render',
    '4': 'capture'
}

# 任务配置
TASK_CONFIGS = {
    'html': {
        'resultStoreKey': 'html:store:%d:%d'
    },
    'render': {
        'resultStoreKey': 'render:store:%d:%d'
    },
    'capture': {
        'resultStoreKey': 'capture:store:%d:%d'
    }
}

# 用户抓取任务配置
USER_CONFIG = {
    'userTaskLimitKey': 'user:limit:%d',
    'userTaskSendedKey': 'user:sended:%d:%s',
    'urlsTable': 'urls_%d',
    'configsTable': 'configs_%d'
}

# IP黑名单配置
BLACK_IP_CONFIG = {
    'blackList': 'black:list'
}

if Ping.ping(DOWNLOADER_CENTER_DB['inner']['host']):
    ENVIR = 'inner'
else:
    ENVIR = 'outer'
