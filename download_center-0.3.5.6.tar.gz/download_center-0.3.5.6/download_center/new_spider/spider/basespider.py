# -*- coding: utf8 -*-
from spider import Spider
from download_center.new_spider.downloader.downloader import Downloader
from download_center.new_spider.downloader import configs
from download_center.new_spider.util.util_md5 import UtilMD5
from download_center.new_spider.util.util_useragent import UtilUseragent
from Queue import LifoQueue
from Queue import Queue
from Queue import Empty
from download_center.store.store_mysql import StoreMysql
from threading import Thread
import time
import traceback
import redis
import datetime
import uuid
import sys
reload(sys)
sys.setdefaultencoding('utf8')


class BaseSpider(Spider):
    """
    基本的爬虫类
    该爬虫维护四个队列：待发送队列sending_queue、已发送队列sended_queue
    取回结果队列response_queue、待存储队列store_queue
    发送的对象统一封装成SpiderRequest对象
    启动时，通过start_requests方法构造一批待发送的SpiderRequest对象送到待发送队列里面
    发送线程send_requests依次从sending_queue队列取值并发送，获取的结果通过deal_request_results来处理
    如果发送成功，将SpiderRequest对象送入已发送队列sended_queue，如果发送失败则重新回到待发送队列sending_queue
    取结果线程get_response依次从sended_queue队列取值并发送，获取的结果放至取回结果队列response_queue，
    deal_response_results从取回结果队列response_queue取出来处理，处理结束后可把结果放至待存储队列store_queue异步存储，也可在
    deal_response_results直接调用stores的存储方法直接存储
    如果抓取成功，将对应结果存入数据库，如果发送失败则重新回到已发送队列sended_queue
    """

    def __init__(self):
        self.pc_user_agents = UtilUseragent.get()
        self.mb_user_agents = UtilUseragent.get(type='MOBILE')
        self.sending_queue = LifoQueue()
        self.sended_queue = Queue()
        self.response_queue = Queue()
        self.store_queue = Queue()
        self.user_id = 0
        self.stores = self.get_stores()

    def get_user_password(self):
        """
        设置用户名和密码，由子类实现。用于爬取前验证是否合法
        """
        raise NotImplementedError()

    def validate_user(self):
        """
        验证用户
        """
        user, password = self.get_user_password()
        db = StoreMysql(**(configs.DOWNLOADER_CENTER_DB[configs.ENVIR]))
        rows = db.query('select id from user where user = "%s" and password = "%s"' % (user, UtilMD5.md5(password)))
        if len(rows) == 1:
            self.user_id = rows[0][0]
        else:
            raise RuntimeError('用户验证失败')

    def get_downloader(self):
        """
        设置下载器类型，默认为Downloader
        Return:
            SpiderDownloader
        """
        return Downloader(set_mode='db', get_mode='db')
        # return HtmlLocalDownloader()

    def start_requests(self):
        """
        初始化待发送请求队列，由子类实现。拼装一串SpiderRequest对象并送到sending_queue队列中
        """
        raise NotImplementedError()

    def is_finish(self):
        """
        根据相关队列是否全都为空来判断任务处理结束
        """
        return self.sending_queue.qsize() == 0 and self.sended_queue.qsize() == 0 \
            and self.response_queue.qsize() == 0 and self.store_queue.qsize() == 0

    def send_wait(self):
        """
        发送等待, 控制发往下载中心的速率
        """
        if self.sended_queue.qsize() > 2000:
            time.sleep(60)
        elif self.sending_queue.qsize() < 10000:
            time.sleep(1)

    def send_requests(self, max_idle_time):
        """
        发送请求。将sending_queue队列中的SpiderRequest对象通过downloader发送到下载中心
        """
        downloader = self.get_downloader()
        start_time = time.time()
        while True:
            try:
                request = self.sending_queue.get_nowait()
                if request.user_id is None:
                    request.user_id = self.user_id
                results = downloader.set(request)
                self.deal_request_results(request, results)
                start_time = time.time()
                self.send_wait()
            except Empty:
                if max_idle_time == -1:
                    pass
                elif start_time + max_idle_time < time.time():
                    if self.is_finish():
                        break
                time.sleep(60)
            except Exception, e1:
                print(traceback.format_exc())

    def deal_request_results(self, request, results):
        """
        发送请求send_requests后的处理逻辑，由子类实现
        Args:
            request:SpiderRequest对象
            results:发送request后的返回对象
        """
        raise NotImplementedError()

    def get_wait(self):
        """
        获取结果等待, 控制发往处理队列的速率
        """
        if self.response_queue.qsize() > 10000:
            time.sleep(60)
        elif self.sended_queue.qsize() < 2000:
            time.sleep(1)

    def get_response(self, max_idle_time):
        """
        获取url爬取结果。将sended_queue队列中的SpiderRequest对象通过downloader到下载中心去获取抓取到的html
        """
        downloader = self.get_downloader()
        start_time = time.time()
        while True:
            try:
                request = self.sended_queue.get_nowait()
                results = downloader.get(request)
                self.response_queue.put((request, results))
                start_time = time.time()
                # self.get_wait()
            except Empty:
                if max_idle_time == -1:
                    pass
                elif start_time + max_idle_time < time.time():
                    if self.is_finish():
                        break
                time.sleep(10)
            except Exception, e1:
                print(traceback.format_exc())

    def deal_response(self, max_idle_time):
        """
        从结果队列response_queue中取出结果进行处理
        """
        start_time = time.time()
        while True:
            try:
                request, results = self.response_queue.get_nowait()
                try:
                    self.deal_response_results(request, results, self.stores)
                except Exception:
                    print(traceback.format_exc())

                self.after_deal_response(request, results)
                start_time = time.time()
            except Empty:
                if max_idle_time == -1:
                    pass
                elif start_time + max_idle_time < time.time():
                    if self.is_finish():
                        break
                time.sleep(10)
            except Exception:
                print(traceback.format_exc())

    def store_results(self, max_idle_time):
        """
        从store_queue里面取出待存储的数据进行存储
        """
        start_time = time.time()
        while True:
            try:
                results = self.store_queue.get_nowait()
                self.to_store_results(results, self.stores)
                start_time = time.time()
            except Empty:
                if max_idle_time == -1:
                    pass
                elif start_time + max_idle_time < time.time():
                    if self.is_finish():
                        break
                time.sleep(10)
            except Exception, e1:
                print(traceback.format_exc())

    def to_store_results(self, results, stores):
        """
        存储结果，由子类实现。
        Args:
            results:处理response后的结果
            stores:list，可能会用到的存储器（SpiderStore）列表
        """
        raise NotImplementedError()

    def get_stores(self):
        """
        设置存储器，供deal_response_results调用
        Return:
            list,成员为SpiderStore对象
        """
        raise NotImplementedError()

    def deal_response_results(self, request, results, stores):
        """
        获取url爬取结果后的处理逻辑，由子类实现。
        Args:
            request:SpiderRequest对象
            results:请求request结果后的返回对象
            stores:list，可能会用到的存储器（SpiderStore）列表
        """
        raise NotImplementedError()

    def record_log(self, idle=1):
        """
        记录抓取日志，用于调整各个线程参数设置
        """
        if idle == -1:
            while True:
                print('sending_queue:%d; sended_queue:%d' % (self.sending_queue.qsize(), self.sended_queue.qsize()))
                # 需要安装objgraph包
                import objgraph
                objgraph.show_most_common_types()
                time.sleep(300)
        else:
            while not self.is_finish():
                print('sending_queue:%d; sended_queue:%d' % (self.sending_queue.qsize(), self.sended_queue.qsize()))
                # 需要安装objgraph包
                import objgraph
                objgraph.show_most_common_types()
                time.sleep(300)

    @staticmethod
    def get_unique_key():
        """
        生成唯一标识
        :return:
        """
        return uuid.uuid1()

    def add_black_ip(self, ip, type, expire_time=6):
        """
        记录IP黑名单
        使用黑名单功能需在发送请求时在config设置param参数中配置任务类型
        config : {param: {'task_type': 1}}
        Args:
            ip: IP地址
            type: 指定任务类型有效
            expire_time: 超时时间(小时)
        """
        rds = redis.StrictRedis(**(configs.DOWNLOADER_CENTER_REDIS[configs.ENVIR]))
        d = datetime.datetime.now()
        d = d + datetime.timedelta(hours=expire_time)
        expire_time = d.strftime("%Y%m%d %H-%M-%S")
        rds.hset(configs.BLACK_IP_CONFIG['blackList'], str(ip)+"_"+str(type), expire_time)

    def clear_task_pool(self):
        """
        清空当前用户已发往下载中心的任务
        :return:
        """
        self.validate_user()
        db = StoreMysql(**(configs.DOWNLOADER_CENTER_DB[configs.ENVIR]))
        i = -1
        while i == -1:
            sql = 'truncate urls_%d' % self.user_id
            i = db.do(sql, flag='rowcount')

    def after_deal_response(self, request, results):
        """
        抓取结果的处理逻辑后的后续操作，按需使用，默认不作任何操作
        :param request:
        :param results:
        :return:
        """
        pass

    def run(self, send_num=1, get_num=1, deal_num=1, store_num=1,
            send_idle_time=600, get_idle_time=600,
            deal_idle_time=600, store_idle_time=600, record_log=False):
        """
        爬虫启动入口
        Args:
            send_num:发送请求线程数，默认为1
            get_num:获取结果线程数，默认为1
            deal_num:处理结果线程数，默认为1
            store_num:存储结果线程数，默认为1
            send_idle_time:发送请求线程超过该时间没有要发送的请求就停止，-1永不停止
            get_idle_time:获取结果线程超过该时间没有要获取的结果就停止，-1永不停止
            deal_idle_time:处理结果线程超过该时间没有要处理的结果就停止，-1永不停止
            store_idle_time:存储结果线程超过该时间没有要存储的结果就停止，-1永不停止
            record_log:定时记录各个队列大小，便于分析抓取效率
        """
        self.validate_user()
        thread_start = Thread(target=self.start_requests)
        thread_start.start()
        threads = list()
        for i in range(0, send_num):
            threads.append(Thread(target=self.send_requests, args=(send_idle_time,)))
        for i in range(0, get_num):
            threads.append(Thread(target=self.get_response, args=(get_idle_time,)))
        for i in range(0, deal_num):
            threads.append(Thread(target=self.deal_response, args=(deal_idle_time,)))
        for i in range(0, store_num):
            threads.append(Thread(target=self.store_results, args=(store_idle_time,)))
        if record_log:
            threads.append(Thread(target=self.record_log, args=(send_idle_time,)))
        for thread in threads:
            thread.start()
        # for thread in threads:
        #     thread.join()
