# -*- coding: utf8 -*-

# 爬虫数据库
DB_SPIDER = {
    'outer': {
        'host': '182.254.155.218',
        'user': 'spider_center',
        'password': 'spiderdb@wd',
        'db': 'spider'
    },
    'inner': {
        'host': '10.105.72.2',
        'user': 'spider_center',
        'password': 'spiderdb@wd',
        'db': 'spider'
    }

}


# redis地址
REDIS = {
    'outer': {
        'host': '182.254.155.218',
        'port': 6379,
        'db': 0,
        'password': '@redisForSpider$'
    },
    'inner': {
        'host': '10.105.72.2',
        'port': 6379,
        'db': 0,
        'password': '@redisForSpider$'
    }
}

ELASTICSEARCH_INDEX_NAME = 'download_transit'
ELASTICSEARCH = {
    'outer': {
        'host': '115.159.158.156',
        'port': 9200,
        'params': {
            'http_auth': ('admin', 'Iknowthat221@')
        }
    },
    'inner': {
        'host': '10.105.209.117',
        'port': 9200,
        'params': {
            'http_auth': ('admin', 'Iknowthat221@')
        }
    }
}

# 任务类型
TASK_TYPE_HTML = 'html'
TASK_TYPE_RENDER = 'render'
TASK_TYPE_CAPTURE = 'capture'

# 任务配置
TASK_CONFIGS = {
    TASK_TYPE_HTML: {
        'taskTypesInDatabase': '1,2',
        'taskQueueCommonKey': 'html:task:common',
        # 新增 地域 的 查排名
        'taskQueueDistrictKey': 'html:task:%d',
        # 'taskQueueAdslSize': 100,

        'taskMaxSendNumDistrict': {
            '3': 1000,
            '2': 400,
            '1': 100
        },

        'taskMaxSendNumCommon': {
            '3': 1000,
            '2': 400,
            '1': 100
        },
        'taskQueueSingleKey': 'html:task:single',
        'taskMaxSendNumSingle': {
            '3': 800,
            '2': 300,
            '1': 100
        },
        'taskQueueConcurrentKey': 'html:task:concurrent',
        'taskMaxSendNumConcurrent': {
            '3': 1000,
            '2': 400,
            '1': 100
        },
        'taskMaxFailTimes': 3,
        'taskFailTimesKey': 'html:task:fail',
        'resultQueueKey': 'html:result',
        'resultStoreKey': 'html:store:%d:%d'
    },
    TASK_TYPE_RENDER: {
        'taskTypesInDatabase': '3',
        'taskQueueCommonKey': 'render:task:common',
        'taskMaxSendNumCommon': {
            '3': 500,
            '2': 200,
            '1': 50
        },
        'taskQueueSingleKey': 'render:task:single',
        'taskMaxSendNumSingle': {
            '3': 250,
            '2': 100,
            '1': 25
        },
        'taskQueueConcurrentKey': 'render:task:concurrent',
        'taskMaxSendNumConcurrent': {
            '3': 500,
            '2': 200,
            '1': 50
        },
        'taskMaxFailTimes': 3,
        'taskFailTimesKey': 'render:task:fail',
        'resultQueueKey': 'render:result',
        'resultStoreKey': 'render:store:%d:%d'
    },
    TASK_TYPE_CAPTURE: {
        'taskTypesInDatabase': '4',
        'taskQueueCommonKey': 'capture:task:common',
        'taskMaxSendNumCommon': {
            '3': 500,
            '2': 200,
            '1': 50
        },
        'taskQueueSingleKey': 'capture:task:single',
        'taskMaxSendNumSingle': {
            '3': 250,
            '2': 100,
            '1': 25
        },
        'taskQueueConcurrentKey': 'capture:task:concurrent',
        'taskMaxSendNumConcurrent': {
            '3': 500,
            '2': 200,
            '1': 50
        },
        'taskMaxFailTimes': 3,
        'taskFailTimesKey': 'capture:task:fail',
        'resultQueueKey': 'capture:result',
        'resultStoreKey': 'capture:store:%d:%d'
    }
}

# 任务各个环节执行时间间隔配置
TASK_TIME_INTERVAL_CONFIGS = {
    TASK_TYPE_HTML: {
        'pushCommon': 5,
        'pushSingle': 15,
        'pushConcurrent': 30,
        'save': 30,
        'reset': 120,
        'clear': 3600,
        'record': 3600*12,
    },
    TASK_TYPE_RENDER: {
        'pushCommon': 10,
        'pushSingle': 30,
        'pushConcurrent': 30,
        'save': 30,
        'reset': 120,
        'clear': 3600,
        'record': 3600 * 12,

    },
    TASK_TYPE_CAPTURE: {
        'pushCommon': 10,
        'pushSingle': 30,
        'pushConcurrent': 30,
        'save': 30,
        'reset': 120,
        'clear': 3600,
        'record': 3600 * 12,

    }
}

# 用户抓取任务配置
USER_CONFIGS = {
    'userListKey': 'user:list',
    'userWeightKey': 'user:weight',
    'userTaskLimitKey': 'user:limit:%d',
    'userTaskSendedKey': 'user:sended:%d:%s',
    'urlsTable': 'urls_%d',
    'configsTable': 'configs_%d'
}

# ADSL机器配置
MACHINE_CONFIGS = {
    'areaKey': 'machine:area'
}

# IP黑名单配置
BLACK_IP_CONFIG = {
    'blackList': 'black:list'
}
