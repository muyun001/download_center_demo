# -*- coding: utf-8 -*-
"""
Created on 2017/10/30 12:55

@author: zhangle
"""
if __name__ == '__main__':
    # main()
    from download_center.store.store_es import StoreEs
    config = {
        'host': '115.159.158.156',
        'port': 9200,
        'params': {
            'http_auth': ('admin', 'Iknowthat221@')
        }
    }
    try:
        es = StoreEs(**config)
        for i in range(14, 15):
            doc_type = 'urls_' + str(i)
            if not es.es.indices.exists("download_transit"):
                es.es.indices.create("download_transit")
            if not es.es.indices.exists_type("download_transit", doc_type):
                body = {
                    "_ttl": {
                        "enabled": True,
                        "default": "1d"
                    }
                }
                es.es.indices.put_mapping(doc_type, body, "download_transit")
    except:
        pass