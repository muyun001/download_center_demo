# -*- coding: utf8 -*-
import os
import sys
PROJECT_PATH = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
sys.path.append(PROJECT_PATH)
from download_center.store.store_mysql import StoreMysql
from download_center.store.store_es import StoreEs
from download_center.new_spider.util.util_md5 import UtilMD5
import redis
import config

import traceback
reload(sys)
sys.setdefaultencoding('utf8')


class UserManage(object):

    def __init__(self):
        self.userConfigs = config.USER_CONFIGS
        self.db = StoreMysql(**config.DB_SPIDER['outer'])
        self.user_id = None

    def add_user(self, user):
        user_id = self.db.save('user', user)
        if user_id > 0:
            urls_table = self.userConfigs['urlsTable'] % user_id
            configs_table = self.userConfigs['configsTable'] % user_id
            self.user_id = self.db.do('create table %s like urls_1' % urls_table)
            self.db.do('create table %s like configs_1' % configs_table)

    def update_config(self):
        try:
            rds = redis.StrictRedis(**config.REDIS)
            rows = self.db.query('select id, weight, low_priority_task_limit, normal_task_limit, '
                                 'high_priority_task_limit from user where status = 1')
            rds.delete(self.userConfigs['userListKey'])
            rds.delete(self.userConfigs['userWeightKey'])
            for row in rows:
                rds.lpush(self.userConfigs['userListKey'], row[0])
                rds.hset(self.userConfigs['userWeightKey'], row[0], row[1])
                rds.hmset(self.userConfigs['userTaskLimitKey'] % row[0], {
                    '1': row[2],
                    '2': row[3],
                    '3': row[4]
                })
        except Exception:
            traceback.format_exc()

    def update_elasticsearch(self):
        try:
            es = StoreEs(**(config.ELASTICSEARCH['outer']))
            doc_type = 'urls_'+str(self.user_id)
            if not es.es.indices.exists(config.ELASTICSEARCH_INDEX_NAME):
                es.es.indices.create(config.ELASTICSEARCH_INDEX_NAME)
            if not es.es.indices.exists_type(config.ELASTICSEARCH_INDEX_NAME, doc_type):
                body = {
                    "_ttl": {
                        "enabled": True,
                        "default": "1d"
                    }
                }
                es.es.indices.put_mapping(doc_type, body, config.ELASTICSEARCH_INDEX_NAME)
        except:
            pass

def main():
    u = UserManage()
    u.add_user({'user': 'chenyang2', 'password': UtilMD5.md5('cyspider'), 'weight': 2})
    u.update_config()
    u.update_elasticsearch()

if __name__ == '__main__':
    # main()
    try:
        es = StoreEs(**(config.ELASTICSEARCH['outer']))
        for i in range(14, 15):
            doc_type = 'urls_' + str(i)
            if not es.es.indices.exists("download_transit"):
                es.es.indices.create("download_transit")
            if not es.es.indices.exists_type("download_transit", doc_type):
                body = {
                    "_ttl": {
                        "enabled": True,
                        "default": "1d"
                    }
                }
                es.es.indices.put_mapping(doc_type, body, "download_transit")
    except:
        pass