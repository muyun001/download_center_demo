from setuptools import setup, find_packages


setup(name='download_center',

      version='0.3.5.6',

      author='HMM, ZL, SX',

      author_email='le.zhang@winndoo.com',

      url='http://www.winndoo.com',

      description='spider framework for winndoo',

      packages=find_packages(exclude=['doc']),
    
      package_data={
        '': ['*.txt']
      },

      install_requires=[
          'pymongo',
          'mysql-python',
          'oss2',
          'redis',
          'DBUtils',
          'elasticsearch',
          'flask',
          'objgraph',
          'lxml',
          'cssselect'
      ]
      )
